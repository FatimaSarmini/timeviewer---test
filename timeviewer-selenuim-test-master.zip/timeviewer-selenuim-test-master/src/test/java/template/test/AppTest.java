package template.test;

import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import com.google.common.base.Charsets;
import com.google.common.io.Resources;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class AppTest 
{
	
	  public static WebDriver driver=null;
	  public static Map<String, Object> vars;
	  public static JavascriptExecutor js;
	  public static WebDriverWait wait ;
	  public static String trackName;
	  public static String trackURL;
	  
  @Test
  public void f() throws Exception {
	  
		
	     System.out.println(trackURL);
	  	 //Thread.sleep(5000);
			/*
			 * wait = new WebDriverWait(driver, 120);
			 * wait.until(ExpectedConditions.elementToBeClickable(By.
			 * cssSelector("#navbarSupportedContent > div:nth-child(3) > button")));
			 * 
			 * String before = driver.findElement(By.
			 * cssSelector("#navbarSupportedContent > div:nth-child(3) > button")).getText()
			 * ;
			 * 
			 * driver.findElement(By.
			 * cssSelector("#navbarSupportedContent > div:nth-child(3) > button")).click();
			 * 
			 * Thread.sleep(5000);
			 * 
			 * String after = driver.findElement(By.
			 * cssSelector("#navbarSupportedContent > div:nth-child(3) > button")).getText()
			 * ;
			 * 
			 * Assert.assertNotEquals(before, after);
			 */
			 
	     System.out.println("Assert passed");
		  
  }
  
  //@Test 
   //public void f2() throws Exception {
	  
	    
	     //Assert.assertNotEquals(true, true);
		  
	    
  //}
  
  @BeforeMethod
  public void beforeMethod() {
	  	
		//////////////////////////////////////
		//When you finish UNCOMMENT this out//
		//////////////////////////////////////
		
		System.setProperty("webdriver.chrome.driver", "drivers/chromedriver"); //For Linux
		
		//////////////////////////////////////
		//When you finish COMMENT this out ///
		//////////////////////////////////////
		//System.setProperty("webdriver.chrome.driver", "drivers/chromedriver.exe"); //For Windows
		
		/////////////////////////////////////////
		/////Headless Chrome ///////////////////
		////////////////////////////////////////
		
		ChromeOptions chromeOptions = new ChromeOptions();
		chromeOptions.addArguments("--headless");
		chromeOptions.addArguments("--no-sandbox");
		chromeOptions.addArguments("--window-size=1920,1080");
		driver = new ChromeDriver(chromeOptions);
		
		
		//driver = new ChromeDriver();//Normal Chrome
		js = (JavascriptExecutor) driver;
		vars = new HashMap<String, Object>();
		
		

	    driver.get(trackURL);
	  	
	  	driver.manage().window().maximize();

	    
  }

  @AfterMethod
  public void afterMethod() throws Exception {
	  
	  //Thread.sleep(5000);
	  driver.quit();
	  
  }
  
  @BeforeClass
  public void beforeClassMethod() {
	  
			trackName= System.getProperty("trackName") ;
		    
		    if ( trackName.equals("live") ) {trackURL="https://timeviewer.tv";}
		    else if (trackName.equals("review") ) {trackURL="https://review.timeviewer.tv";}
		    else {trackURL="https://dev.timeviewer.tv";}
	  
  }
  
  @AfterClass 
  public void afterClassMethod() {
	  
	   
	  
  }
   
}
